﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace AgricultureCompostOrderingSystemProject.ProjectFile
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\asp.net\AgricultureCompostOrderingSystemProject\AgricultureCompostOrderingSystemProject\App_Data\AgrryDataBase.mdf;Integrated Security=True");
            SqlCommand cmd;

            con.Open();
            try
            {
                string strOrder = "insert into TblOrder Values('"+txtFullName.Text+"','"+txtCity.Text+"','"+txtEmail.Text+"',"+txtMobile.Text+",'"+DropDownListCompost.SelectedValue.ToString()+"','"+DropDownListCompost2.SelectedValue.ToString()+"','"+txtAddress.Text+"')";
                cmd = new SqlCommand(strOrder, con);
                cmd.ExecuteNonQuery();

                Response.Write("<script>alert('Order Confirm Successfully')</script>");
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}