﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace AgricultureCompostOrderingSystemProject.ProjectFile
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignIn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\asp.net\AgricultureCompostOrderingSystemProject\AgricultureCompostOrderingSystemProject\App_Data\AgrryDataBase.mdf;Integrated Security=True");
            SqlCommand cmd;

            con.Open();
            try
            {
                string strRegister = "insert into TblUsers values('"+txtFirstName.Text+"','"+txtLastName.Text+"','"+txtEmail.Text+"',"+txtMobile.Text+",'"+txtPassword.Text+"')";
                cmd = new SqlCommand(strRegister, con);
                cmd.ExecuteNonQuery();

                Response.Write("<script>alert('Registration Successfully')</script>");
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}