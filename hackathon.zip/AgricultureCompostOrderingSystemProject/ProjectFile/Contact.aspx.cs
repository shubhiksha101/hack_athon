﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace AgricultureCompostOrderingSystemProject.ProjectFile
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\asp.net\AgricultureCompostOrderingSystemProject\AgricultureCompostOrderingSystemProject\App_Data\AgrryDataBase.mdf;Integrated Security=True");
            SqlCommand cmd;

            con.Open();
            try
            {
                string strcontact = "insert into TblFeedbacl values('"+txtName.Text+"',"+txtMobile.Text+",'"+txtEmail.Text+"','"+txtSubject.Text+"','"+txtMessage.Text+"')";
                cmd = new SqlCommand(strcontact, con);
                cmd.ExecuteNonQuery();

                Response.Write("<script>alert('Feedback Send Successfully')</script>");
            }
            catch(Exception ex)
            {
                Response.Write(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}